-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 22 2020 г., 00:05
-- Версия сервера: 5.6.47
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `tasks`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cookies`
--

CREATE TABLE `cookies` (
  `id` int(12) NOT NULL,
  `login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `cookies`
--

INSERT INTO `cookies` (`id`, `login`, `pass`) VALUES
(1, 'user1', 'draormybs32.87d8578edf8458ce06fbc5bb76a58c5ca4drao'),
(2, 'user2', 'draormybs32.87202cb962ac59075b964b07152d234b70drao'),
(3, '1234', 'draormybs32.8781dc9bdb52d04dc20036dbd8313ed055drao'),
(4, '345', 'draormybs32.87d81f9c1be2e08964bf9f24b15f0e4900drao'),
(5, '32', '32'),
(6, 'user2', 'user2'),
(7, 'user2', 'user2'),
(8, 'user23', 'user23'),
(9, 'user233', 'user233'),
(10, 'user3', 'user3'),
(11, 'user44', 'draormybs32.8793b1ad3cfaeb254ea3c68ee7ea23c582drao'),
(12, 'qwerty', 'draormybs32.87d8578edf8458ce06fbc5bb76a58c5ca4drao'),
(13, 'user8', 'draormybs32.877668f673d5669995175ef91b5d171945drao'),
(14, '3232', 'draormybs32.87d41d8cd98f00b204e9800998ecf8427edrao'),
(15, '32324', 'd41d8cd98f00b204e9800998ecf8427e'),
(16, '4343', '7215ee9c7d9dc229d2921a40e899ec5f'),
(17, '43', '17e62166fc8586dfa4d1bc0e1742c08b'),
(18, '123', '202cb962ac59075b964b07152d234b70'),
(19, '567', '99c5e07b4d5de9d18c350cdf64c5aa3d'),
(20, 'userr', '7dc715960b177f323db34eacd63048f7'),
(21, 'GoodForYou', '13f45e82f2fd4cd34bd7b0221b87a0bd'),
(22, 'qq', '099b3b060154898840f0ebdfb46ec78f'),
(23, 'qq1', '53426eecbae3ef56b1c80769c81f4722');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cookies`
--
ALTER TABLE `cookies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cookies`
--
ALTER TABLE `cookies`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
