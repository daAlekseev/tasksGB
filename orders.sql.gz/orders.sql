-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 05 2020 г., 13:57
-- Версия сервера: 5.6.47
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `tasks`
--

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(12) NOT NULL,
  `customerName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerNumber` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerText` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `items` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(12) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orderState` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `customerName`, `customerNumber`, `customerText`, `items`, `price`, `date`, `orderState`) VALUES
(1, 'goodforyou', '+79211925555', 'Комментарий', ' Pixel(x3) OnePlus(x1) ', 3546, '2020-11-02 20:33:52', 0),
(2, 'Иван', '+79234567898', '', ' Samsung(x1) iPhone(x1) ', 1990, '2020-11-02 21:07:03', 1),
(3, 'admin', '557-77-21', 'Для администратора ', ' iPhone(x1) Samsung(x1) Xiaomi(x1) OnePlus(x1) ', 3248, '2020-11-03 12:30:54', 0),
(4, 'goodforyou', '89113421234', '', ' iPhone(x1) OnePlus(x2) ', 2592, '2020-11-03 14:52:14', 1),
(5, 'userDenis', '89111223445', '', ' OnePlus(x1) ', 940, '2020-11-04 22:16:40', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
